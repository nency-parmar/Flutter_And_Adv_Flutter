import 'package:advance_flutter_lab/utils/import_export.dart';

class Catagory extends StatelessWidget {
  final List<dynamic> catagories;

  const Catagory({super.key, required this.catagories});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 60,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: catagories.length,
        itemBuilder: (context, index) {
          return Padding(
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: Chip(
              label: Text(catagories[index]),
              backgroundColor: Colors.blueAccent,
            ),
          );
        },
      ),
    );
  }
}
