import 'package:advance_flutter_lab/utils/import_export.dart';

class ProductDetail extends StatelessWidget {
  List<dynamic> products = [];
  int index;
  ProductDetail({super.key , required this.products , required this.index});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.blue, Colors.blueAccent],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        title: Text(APPBAR_TITLE_OF_PRODUCT_DETAIL_PAGE , style: TextStyle(fontWeight: FontWeight.bold),),
      ),
      body: Padding(
        padding: const EdgeInsets.all(18.0),
        child: Column(
          children: [
            Expanded(
                child: Image.network(
                  products[index][PRODCUT_URL],
                )
            ),
            Row(
              children: [
                Expanded(
                  child: Column(
                    children: [
                      Text(products[index][PRODUCT_NAME].toString()),
                      Text(products[index][PRODUCT_PRICE].toString()),
                    ],
                  ),
                ),
                IconButton(onPressed: () {

                }, icon: Icon(Icons.edit),),
                IconButton(onPressed: () {

                }, icon: Icon(Icons.delete),),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
