import 'package:advance_flutter_lab/lab2/e-commerce_application/product_views/banner.dart';
import 'package:advance_flutter_lab/lab2/e-commerce_application/product_views/cart_page_view.dart';
import 'package:advance_flutter_lab/lab2/e-commerce_application/product_views/catagory.dart';
import 'package:advance_flutter_lab/lab2/e-commerce_application/product_views/product_detail.dart';
import 'package:advance_flutter_lab/utils/import_export.dart';

class ProductView extends StatefulWidget {
  ProductView({super.key});

  static ProductController controller = ProductController();

  @override
  State<ProductView> createState() => _ProductViewState();
}

class _ProductViewState extends State<ProductView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.blue, Colors.blueAccent],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        centerTitle: true,
        title: Text(
          APPBAR_TITLE_OF_E_COMMERCE_VIEW_PAGE,
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 30),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: IconButton(
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(builder: (context) => CartPageView()));
              },
                icon:Icon(Icons.shopping_cart_rounded)),
          )
        ],
      ),
      body: ListView(
        children: [
          Catagory(catagories: ProductView.controller.categories),
          BannerClass(),
          GridView.builder(
            shrinkWrap: true,
            gridDelegate:
                SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
            itemBuilder: (context, index) {
              dynamic products = ProductView.controller.getProduct();
              return Card(
                child: InkWell(
                  onTap: () {
                    Navigator.of(context).push(MaterialPageRoute(builder: (context) {
                      return ProductDetail(products: ProductView.controller.getProduct().toList(), index: index,);
                    },));
                  },
                  child: Column(
                    children: [
                      Expanded(
                          child: Image.network(
                        products[index][PRODCUT_URL],
                      )),
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              children: [
                                Text(products[index][PRODUCT_NAME].toString()),
                                Text(products[index][PRODUCT_PRICE].toString()),
                              ],
                            ),
                          ),
                          IconButton(onPressed: () {
                            ProductView.controller.carted_products.add(products[index]);
                          }, icon: Icon(Icons.add_shopping_cart_sharp),),
                        ],
                      ),

                    ],
                  ),
                ),
              );
            },
            itemCount: ProductView.controller.getProduct().length,
          )
        ],
      ),
      drawer: Drawer(
        child: Column(
          children: [
            Container(
              width: double.infinity, // 100% width
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.indigo, Colors.deepPurple],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: SafeArea(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    CircleAvatar(
                      backgroundColor: Colors.white,
                      radius: 30,
                      child: Icon(Icons.person, size: 30, color: Colors.indigo),
                    ),
                    SizedBox(height: 10),
                    Text(
                      "Welcome!",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "ShopLazy",
                      style: TextStyle(color: Colors.white70 , fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: ListView(
                children: [
                  ListTile(
                    leading: Icon(Icons.add_box_outlined, color: Colors.indigo),
                    title: Text(
                      "Add Product",
                      style: TextStyle(fontWeight: FontWeight.w500),
                    ),
                    onTap: () {
                      Navigator.of(context)
                          .push(MaterialPageRoute(builder: (_) => AddProduct()))
                          .then((value) {
                        setState(() {});
                      });
                    },
                  ),
                  Divider(),
                  ListTile(
                    leading: Icon(Icons.logout, color: Colors.redAccent),
                    title: Text("Logout"),
                    onTap: () {
                      // handle logout
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
