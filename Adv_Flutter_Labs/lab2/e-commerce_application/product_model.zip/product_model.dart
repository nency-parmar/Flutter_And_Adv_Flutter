import 'package:advance_flutter_lab/utils/import_export.dart';
import 'package:advance_flutter_lab/utils/strings.dart';

import '../../utils/strings.dart';
class ProductModel{
  List<Map<String , dynamic>> productList = [
    {
      PRODUCT_NAME : "iPhone 16",
      PRODUCT_PRICE : "1500",
      PRODCUT_URL : "https://inspireonline.in/cdn/shop/files/iPhone_16_Teal_PDP_Image_Position_1__en-IN_6aed3712-113a-4579-8a71-41c02aa0003c.jpg?v=1727247732"
    },
    {
      PRODUCT_NAME : "iPhone 16",
      PRODUCT_PRICE : "1500",
      PRODCUT_URL : "https://inspireonline.in/cdn/shop/files/iPhone_16_Teal_PDP_Image_Position_1__en-IN_6aed3712-113a-4579-8a71-41c02aa0003c.jpg?v=1727247732"
    },
    {
      PRODUCT_NAME : "iPhone 16",
      PRODUCT_PRICE : "1500",
      PRODCUT_URL : "https://inspireonline.in/cdn/shop/files/iPhone_16_Teal_PDP_Image_Position_1__en-IN_6aed3712-113a-4579-8a71-41c02aa0003c.jpg?v=1727247732"
    }
  ];

  List<dynamic> getProductList(){
    return productList;
  }

  void addProduct(dynamic product){
    if(!productList.contains(product)){
      productList.add(product);
    }
  }

  void deleteProduct(int index){
    if(productList.contains(productList[index])){
      productList.removeAt(index);
    }
  }

  void updateProduct(dynamic product , int index){
    if(productList.contains(productList[index])){
      productList[index] = product;
    }
  }

}