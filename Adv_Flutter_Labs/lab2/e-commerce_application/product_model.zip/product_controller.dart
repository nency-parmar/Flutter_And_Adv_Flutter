import 'package:advance_flutter_lab/utils/import_export.dart';

class ProductController{

  ProductModel _model = ProductModel();

  List<dynamic> categories  = ['Electricals' , 'Home Appliances' , 'Clothing' , 'Skin and Hair'];
  List<dynamic> carted_products = [];

  List<dynamic> getProduct() => _model.getProductList();

  List<dynamic> getCartProdicts() => carted_products;

  void addProduct(dynamic product) => _model.addProduct(product);


}